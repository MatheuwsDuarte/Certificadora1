document.addEventListener('DOMContentLoaded', function() {
    // Mobile menu toggle
    const mobileMenuBtn = document.querySelector('.mobile-menu-btn');
    const nav = document.querySelector('nav');
    
    mobileMenuBtn.addEventListener('click', function() {
        nav.classList.toggle('active');
    });

    // A navegação entre arquivos HTML foi deixada nativa (sem JS interceptando)

    // Calendar functionality
    initializeCalendar();

    // Form submissions
    setupFormSubmissions();

    // Modal functionality
    setupModal();

    // Sample data for tables
    populateSampleData();
});

function initializeCalendar() {
    const currentMonthElement = document.getElementById('current-month');
    const calendarDaysElement = document.getElementById('calendar-days');
    const prevMonthBtn = document.getElementById('prev-month');
    const nextMonthBtn = document.getElementById('next-month');

    let currentDate = new Date();
    let currentMonth = currentDate.getMonth();
    let currentYear = currentDate.getFullYear();

    function renderCalendar(month, year) {
        const monthNames = ["Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho", "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro"];
        currentMonthElement.textContent = `${monthNames[month]} ${year}`;

        const firstDay = new Date(year, month, 1).getDay();
        const daysInMonth = new Date(year, month + 1, 0).getDate();

        calendarDaysElement.innerHTML = '';

        for (let i = 0; i < firstDay; i++) {
            const emptyDay = document.createElement('div');
            emptyDay.classList.add('calendar-day', 'empty');
            calendarDaysElement.appendChild(emptyDay);
        }

        for (let day = 1; day <= daysInMonth; day++) {
            const dayElement = document.createElement('div');
            dayElement.classList.add('calendar-day');

            const dayNumber = document.createElement('div');
            dayNumber.classList.add('day-number');
            dayNumber.textContent = day;
            dayElement.appendChild(dayNumber);

            if (day % 5 === 0) {
                const event = document.createElement('div');
                event.classList.add('event');
                event.textContent = 'Palestra';
                event.addEventListener('click', function() {
                    openEventModal(day, month, year);
                });
                dayElement.appendChild(event);
            }

            if (day % 7 === 0) {
                const event = document.createElement('div');
                event.classList.add('event');
                event.textContent = 'Distribuição';
                event.addEventListener('click', function() {
                    openEventModal(day, month, year);
                });
                dayElement.appendChild(event);
            }

            calendarDaysElement.appendChild(dayElement);
        }
    }

    prevMonthBtn.addEventListener('click', function() {
        currentMonth--;
        if (currentMonth < 0) {
            currentMonth = 11;
            currentYear--;
        }
        renderCalendar(currentMonth, currentYear);
    });

    nextMonthBtn.addEventListener('click', function() {
        currentMonth++;
        if (currentMonth > 11) {
            currentMonth = 0;
            currentYear++;
        }
        renderCalendar(currentMonth, currentYear);
    });

    renderCalendar(currentMonth, currentYear);
}

function setupFormSubmissions() {
    document.getElementById('donation-form').addEventListener('submit', function(e) {
        e.preventDefault();
        alert('Doação registrada com sucesso!');
        this.reset();
    });

    document.getElementById('volunteer-form').addEventListener('submit', function(e) {
        e.preventDefault();
        alert('Cadastro de voluntário realizado com sucesso!');
        this.reset();
    });

    document.getElementById('beneficiary-form').addEventListener('submit', function(e) {
        e.preventDefault();
        alert('Cadastro de beneficiária realizado com sucesso!');
        this.reset();
    });
}

function setupModal() {
    const modal = document.getElementById('event-modal');
    const addEventBtn = document.getElementById('add-event');
    const closeModal = document.querySelector('.close-modal');
    const eventForm = document.getElementById('event-form');

    addEventBtn.addEventListener('click', function() {
        document.getElementById('modal-title').textContent = 'Adicionar Novo Evento';
        eventForm.reset();
        document.getElementById('event-id').value = '';
        modal.style.display = 'flex';
    });

    closeModal.addEventListener('click', function() {
        modal.style.display = 'none';
    });

    window.addEventListener('click', function(e) {
        if (e.target === modal) {
            modal.style.display = 'none';
        }
    });

    eventForm.addEventListener('submit', function(e) {
        e.preventDefault();
        alert('Evento salvo com sucesso!');
        modal.style.display = 'none';
    });
}

function openEventModal(day, month, year) {
    const modal = document.getElementById('event-modal');
    const eventForm = document.getElementById('event-form');

    document.getElementById('modal-title').textContent = 'Detalhes do Evento';
    document.getElementById('event-name').value = 'Palestra sobre saúde menstrual';
    document.getElementById('event-date').value = `${year}-${String(month + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
    document.getElementById('event-time').value = '14:00';
    document.getElementById('event-location').value = 'Auditório da UTFPR';
    document.getElementById('event-description').value = 'Palestra aberta ao público sobre saúde menstrual e combate à pobreza menstrual.';

    modal.style.display = 'flex';
}

function populateSampleData() {
    const donationsTable = document.getElementById('donations-table');
    const sampleDonations = [
        { name: 'Maria Silva', type: 'Absorventes Descartáveis', quantity: 50, date: '15/06/2023' },
        { name: 'Empresa XYZ', type: 'Doação em Dinheiro', quantity: 'R$ 500,00', date: '10/06/2023' },
        { name: 'Ana Oliveira', type: 'Coletores Menstruais', quantity: 10, date: '05/06/2023' },
        { name: 'Projeto ABC', type: 'Calcinhas Absorventes', quantity: 20, date: '01/06/2023' }
    ];

    sampleDonations.forEach(donation => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${donation.name}</td>
            <td>${donation.type}</td>
            <td>${donation.quantity}</td>
            <td>${donation.date}</td>
            <td class="table-actions">
                <button class="table-btn edit-btn">Editar</button>
                <button class="table-btn delete-btn">Excluir</button>
            </td>
        `;
        donationsTable.appendChild(row);
    });

    const volunteersTable = document.getElementById('volunteers-table');
    const sampleVolunteers = [
        { name: 'Joana Santos', course: 'Engenharia', skills: 'Organização de eventos', availability: 'Tarde, FDS' },
        { name: 'Pedro Almeida', course: 'Psicologia', skills: 'Aconselhamento', availability: 'Manhã, Noite' },
        { name: 'Carla Mendes', course: 'Enfermagem', skills: 'Palestras sobre saúde', availability: 'Eventos' },
        { name: 'Lucas Oliveira', course: 'Administração', skills: 'Logística', availability: 'Manhã, Tarde' }
    ];

    sampleVolunteers.forEach(volunteer => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${volunteer.name}</td>
            <td>${volunteer.course}</td>
            <td>${volunteer.skills}</td>
            <td>${volunteer.availability}</td>
            <td class="table-actions">
                <button class="table-btn edit-btn">Editar</button>
                <button class="table-btn delete-btn">Excluir</button>
            </td>
        `;
        volunteersTable.appendChild(row);
    });

    const beneficiariesTable = document.getElementById('beneficiaries-table');
    const sampleBeneficiaries = [
        { name: 'Fernanda Costa', course: 'Engenharia', needs: 'Absorventes', frequency: 'Mensal', last: '10/06/2023' },
        { name: 'Amanda Lima', course: 'Letras', needs: 'Coletores', frequency: 'Bimestral', last: '05/06/2023' },
        { name: 'Juliana Rocha', course: 'Medicina', needs: 'Kits completos', frequency: 'Trimestral', last: '01/06/2023' },
        { name: 'Patrícia Souza', course: 'Arquitetura', needs: 'Calcinhas absorventes', frequency: 'Mensal', last: '30/05/2023' }
    ];

    sampleBeneficiaries.forEach(beneficiary => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${beneficiary.name}</td>
            <td>${beneficiary.course}</td>
            <td>${beneficiary.needs}</td>
            <td>${beneficiary.frequency}</td>
            <td>${beneficiary.last}</td>
            <td class="table-actions">
                <button class="table-btn edit-btn">Editar</button>
                <button class="table-btn delete-btn">Excluir</button>
            </td>
        `;
        beneficiariesTable.appendChild(row);
    });

    document.querySelectorAll('.delete-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            if (confirm('Tem certeza que deseja excluir este registro?')) {
                this.closest('tr').remove();
            }
        });
    });

    document.querySelectorAll('.edit-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            alert('Funcionalidade de edição será implementada na próxima versão.');
        });
    });
}
